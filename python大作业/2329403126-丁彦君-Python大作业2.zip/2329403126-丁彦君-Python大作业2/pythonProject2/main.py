import os
import xml.etree.ElementTree as ET
import re
import threading
import time

# 页面生成器
def func1(path1):
    if not os.path.exists(path1):
        print(f"文件 {path1} 不存在")
        return
    with open(path1, "r", encoding="utf-8", errors="ignore") as res:
        t = False
        ans = []
        for line in res:
            if "<page>" in line:
                t = True
                ans = [line]
            elif "</page>" in line:
                ans.append(line)
                yield "".join(ans)
                t = False
                ans = []
            elif t:
                ans.append(line)

# 多线程搜索器类
class SearchThread(threading.Thread):
    def __init__(self, term, path1):
        super().__init__()
        self.term = term
        self.path1 = path1
        self.stop1 = False  # 停止标志
        self.pause1 = threading.Event()  # 暂停事件
        self.pause1.set()  # 默认设置为非暂停状态
        self.start_time = None  # 开始时间
        self.end_time = None  # 结束时间

    def run(self):
        self.start_time = time.time()
        for ans in func1(self.path1):
            self.pause1.wait()  # 如果线程被暂停，这里会阻塞直到恢复
            if self.stop1:
                print("搜索已停止")
                break
            try:
                root = ET.fromstring(ans)
                id = root.find("id").text
                title1 = root.find("title")
                title = title1.text if title1 is not None else "无标题"
                text1 = root.find("revision/text")
                text = text1.text if text1 is not None else ""
                if (text and re.search(re.escape(self.term), text, re.IGNORECASE)) or (
                        title and re.search(re.escape(self.term), title, re.IGNORECASE)):
                    print(f"找到 '{self.term}'，页面ID: {id}")
            except ET.ParseError:
                continue
        self.end_time = time.time()
        total_time = self.end_time - self.start_time
        print(f"搜索完成，耗时: {total_time:.2f} 秒")

    def stop(self):
        self.stop1 = True  # 停止线程
        self.pause1.set()  # 如果线程处于暂停状态，解除暂停以便结束

    def pause(self):
        print("搜索已暂停")
        self.pause1.clear()  # 阻止线程继续执行

    def resume(self):
        print("继续搜索")
        self.pause1.set()  # 解除暂停，继续执行

# 主功能入口
def main():
    path1 = "1.xml"
    term = input("请输入要搜索的词组或单词: ")

    ss = SearchThread(term, path1)  # 创建线程
    ss.start()  # 启动搜索线程

    while True:
        cmd = input("输入命令 ('p' 暂停, 'r' 恢复, 's' 停止, 'q' 退出程序): \n").strip().lower()
        if cmd == "p":
            ss.pause()
        elif cmd == "r":
            ss.resume()
        elif cmd == "s":
            ss.stop()
            ss.join()  # 等待线程结束
            break
        elif cmd == 'q':
            if ss.is_alive():
                ss.stop()  # 停止搜索线程
            break

    if ss.is_alive():
        ss.join()  # 等待线程结束

if __name__ == "__main__":
    main()
