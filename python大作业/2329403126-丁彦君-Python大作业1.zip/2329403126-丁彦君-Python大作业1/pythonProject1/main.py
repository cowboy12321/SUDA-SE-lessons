import os
from pypinyin import pinyin, Style

skip = ['，', '：', '。', '.', '？', '/', '、', '|', '!','！','@', '#', '￥', '%', '（', '）', '-', '=', '+', '_', '——', '；']

def func(ss):
    res = []
    for s in ss:
        s = s.strip()
        res1 = ''
        l = len(s)
        i = 0
        while i < l:
            j = l
            judge = False
            while j > i:
                t = s[i:j]
                list1 = pinyin(t, style=Style.NORMAL, heteronym=True)
                if list1 and len(list1) == len(t):
                    for y in range(len(t)):
                        if t[y] not in skip:
                            res1 += t[y] + '（' + list1[y][0] + '）'
                        else:
                            res1 += t[y]
                    i = j
                    judge = True
                    break
                j -= 1
            if not judge:
                res1 += s[i]
                i += 1
        res.append(res1)
    return res

if __name__ == "__main__":
    a = input("请输入导入的文件名: ")
    b = input("请输入需要创建并且输出的文件名: ")

    with open(a, 'r', encoding='utf-8') as x:
        ss = x.readlines()

    y = func(ss)

    with open(b, 'w', encoding='utf-8') as fout:
        for s in y:
            fout.write(s + '\n')
    print(f"拼音标注完成，已经输出到文件: {b}")